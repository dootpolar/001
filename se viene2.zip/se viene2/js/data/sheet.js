var endpoint = "https://script.google.com/macros/s/AKfycbyFhTomfLeo_Y1-0epSlq_IQCO7kUOCfHZaz8MwnanATrrtxSBG3_QoZAEW0EHdr57h2A/exec";

function fetchData(action, callback) {
    $.ajax({
      url: endpoint,
      method: 'POST',
      dataType: 'json',
      data: { action: action },
      success: callback
    });
}

