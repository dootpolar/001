document.addEventListener('DOMContentLoaded', function() {
  // Filtros
  function toggleSearchFilters() {
      var filters = document.getElementById("search-filters");
      filters.style.display = (filters.style.display === "none" ? "flex" : "none");
  }
  document.querySelector('.filter').addEventListener('click', toggleSearchFilters);

  // -----------------------------------------------------------

  // Dropdown
  function closeAllDropdowns() {
      document.querySelectorAll('.dropdown-content').forEach(content => content.classList.remove('show'));
  }

  function closeAllDropdownsExcept(id) {
      document.querySelectorAll('.dropdown-content').forEach(content => {
          if (content.id !== id) content.classList.remove('show');
      });
  }

  document.querySelectorAll('.dropbtn').forEach(btn => {
      btn.addEventListener('click', function(e) {
          var dropdown = document.getElementById(btn.getAttribute('data-dropdown'));
          closeAllDropdownsExcept(dropdown.id);
          dropdown.classList.toggle('show');
          e.stopPropagation();
      });
  });

  document.querySelectorAll('.dropdown-content').forEach(content => {
      content.addEventListener('click', function(e) {
          if (e.target.tagName === 'A') content.classList.remove('show');
          e.stopPropagation();
      });
  });

  window.addEventListener('click', closeAllDropdowns);

  // -----------------------------------------------------------

    // Modal
    function openModal(modal) {
      if (modal) {
          modal.style.display = "block";
          document.body.classList.add("modal-active");
          setTimeout(() => {
              modal.style.opacity = "1";
              modal.querySelector('.modal-content').style.opacity = "1";
              modal.querySelector('.modal-content').style.transform = "scale(1)";
          }, 10);
      }
  }

  function closeModal(modal) {
      if (modal) {
          modal.style.opacity = "0";
          modal.querySelector('.modal-content').style.opacity = "0";
          modal.querySelector('.modal-content').style.transform = "scale(0.7)";
          setTimeout(() => {
              modal.style.display = "none";
              document.body.classList.remove("modal-active");
          }, 300);
      }
  }

  document.querySelectorAll('.btn').forEach(button => {
      button.addEventListener('click', function() {
          var modalId = this.getAttribute('data-modal');
          if (modalId) {
              var modal = document.getElementById(modalId);
              openModal(modal);
          }
      });
  });

  document.querySelectorAll('.close-modal').forEach(close => {
      close.addEventListener('click', function() {
          var modal = this.closest('.modal');
          closeModal(modal);
      });
  });

  document.querySelectorAll('.close').forEach(close => {
      close.addEventListener('click', function() {
          var modal = this.closest('.modal');
          closeModal(modal);
      });
  });

  window.addEventListener('click', function(event) {
      if (event.target.classList.contains('modal')) {
          closeModal(event.target);
      }
  });
});