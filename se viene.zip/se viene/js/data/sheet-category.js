// sheet-category.js
$(document).ready(function() {
  fetchData('getCategorias', function(response) {
    updateTable('categoriasTable', response);
  });
});

function updateTable(elementId, data) {
  var tableBody = $('#' + elementId).find('tbody');
  tableBody.empty();

  data.forEach(function(row) {
    var tr = $('<tr>');
    $('<td>').append($('<img>').attr('src', row.Imagen).css({ width: '50px', height: '50px' })).appendTo(tr);
    $('<td>').text(row.Categoria).appendTo(tr);
    $('<td>').text(row['Categoria principal']).appendTo(tr);
    $('<td>').text(row['Cantidad de producto']).appendTo(tr);
    $('<td>').text(row['Cantidad de stock']).appendTo(tr);
    $('<td>').text(row['Total Precio - Costo']).appendTo(tr);

    var dropdownId = 'KEY-' + row.KEY;
    var dropdownHtml = `
      <div class="dropdown">
        <button class="dropbtn btn" data-dropdown="${dropdownId}">Acción</button>
        <div class="dropdown-content" id="${dropdownId}">
          <a href="#" class="edit-category" data-key="${row.KEY}">Editar</a>
          <a href="#" class="delete-category" data-key="${row.KEY}">Eliminar</a>
        </div>
      </div>
    `;
    $('<td>').append(dropdownHtml).appendTo(tr);

    tableBody.append(tr);
  });

  keyDropdown();
}

function keyDropdown() {
  // Close all dropdowns if somewhere outside is clicked
  $(window).off('click').on('click', function() {
      $('.dropdown-content').removeClass('show');
  });

  // Delegar eventos de clic para dropdowns
  $(document).off('click', '.dropbtn').on('click', '.dropbtn', function(e) {
      var dropdownContentId = $(this).data('dropdown');
      $('.dropdown-content').not($('#' + dropdownContentId)).removeClass('show');
      $('#' + dropdownContentId).toggleClass('show');
      e.stopPropagation();
  });
}
