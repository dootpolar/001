$(document).ready(function() {
  fetchData('getProductos', function(response) {
    updateProductosTable('productosTable', response);
  });
});

function updateProductosTable(elementId, data) {
  var tableBody = $('#' + elementId).find('tbody');
  tableBody.empty();

  data.forEach(function(row) {
    var tr = $('<tr>');
    // Assuming the 'Imagen del Producto' is the URL to the image
    $('<td>').append($('<img>').attr('src', row['Imagen del Producto:']).css({ width: '50px', height: '50px' })).appendTo(tr);
    // Combine several fields into one cell for "Producto"
    var productDetails = row['Marca'] + ' ' + row['Modelo'] + ' ' + row['Descripcion'];
    $('<td>').text(productDetails).appendTo(tr);
    $('<td>').text(row['Cantidad']).appendTo(tr);
    $('<td>').text(row['Precio']).appendTo(tr);
    $('<td>').text(row['Costo']).appendTo(tr);
    $('<td>').text(row['Total Precio - Costo']).appendTo(tr);
    // Add an 'Acción' button
    $('<td>').append($('<button>').text('Acción').addClass('btn')).appendTo(tr);
    tableBody.append(tr);
  });
}
